#include <stdio.h>

enum Codes { A = 10, B, C, D };

int main() {
    printf("%d %d %d %d", A, B, C, D);
    return 0;
}
