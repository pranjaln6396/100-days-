#include <stdio.h>
int main() {
    float c, f;
    scanf("%f", &c);
    f = (c * 9 / 5) + 32;
    printf("Fahrenheit=%.0f\n", f);
    return 0;
}
