#include <stdio.h>

enum Test { X = 5, Y = 20, Z = 100 };

int main() {
    printf("X=%d Y=%d Z=%d", X, Y, Z);
    return 0;
}
#include <stdio.h>

enum Test { X = 5, Y = 20, Z = 100 };

int main() {
    printf("X=%d Y=%d Z=%d", X, Y, Z);
    return 0;
}
