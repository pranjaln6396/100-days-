#include <stdio.h>

int main() {
    FILE *fp;
    char text[256];
    fp = fopen
