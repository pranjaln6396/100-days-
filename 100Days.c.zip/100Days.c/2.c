#include <stdio.h>
int main() {
    int a, b;
    scanf("%d %d", &a, &b);
    printf("Sum=%d", a + b);
    printf(", Diff=%d", a - b);
    printf(", Product=%d", a * b);
    if (b != 0)
        printf(", Quotient=%d\n", a / b);
    else
        printf(", Quotient=undefined\n");
    return 0;
}
